﻿namespace FPClient
{
    partial class LogManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelInfo = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.labelTotal = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btnEmptyGLogData = new System.Windows.Forms.Button();
            this.btnReadAllGLogData = new System.Windows.Forms.Button();
            this.btnReadGLogData = new System.Windows.Forms.Button();
            this.btnReadGLogDataLongID = new System.Windows.Forms.Button();
            this.checkBoxNew = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // labelInfo
            // 
            this.labelInfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelInfo.Location = new System.Drawing.Point(84, 13);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(654, 32);
            this.labelInfo.TabIndex = 0;
            this.labelInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(12, 104);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(818, 315);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Location = new System.Drawing.Point(13, 86);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(41, 12);
            this.labelTotal.TabIndex = 2;
            this.labelTotal.Text = "Total:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(734, 86);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(96, 16);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "ReadOnceMark";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(743, 441);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(87, 23);
            this.btnOK.TabIndex = 5;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(255, 436);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(136, 28);
            this.button8.TabIndex = 4;
            this.button8.Text = "Udisk Read SLogData";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(397, 437);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(135, 26);
            this.button9.TabIndex = 4;
            this.button9.Text = "Udisk Read GLogData";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.UDGLogRead_Click);
            // 
            // btnEmptyGLogData
            // 
            this.btnEmptyGLogData.Location = new System.Drawing.Point(164, 436);
            this.btnEmptyGLogData.Name = "btnEmptyGLogData";
            this.btnEmptyGLogData.Size = new System.Drawing.Size(85, 26);
            this.btnEmptyGLogData.TabIndex = 4;
            this.btnEmptyGLogData.Text = "Empty";
            this.btnEmptyGLogData.UseVisualStyleBackColor = true;
            this.btnEmptyGLogData.Click += new System.EventHandler(this.btnEmptyGLogData_Click);
            // 
            // btnReadAllGLogData
            // 
            this.btnReadAllGLogData.Location = new System.Drawing.Point(86, 436);
            this.btnReadAllGLogData.Name = "btnReadAllGLogData";
            this.btnReadAllGLogData.Size = new System.Drawing.Size(72, 23);
            this.btnReadAllGLogData.TabIndex = 5;
            this.btnReadAllGLogData.Text = "Read All";
            this.btnReadAllGLogData.UseVisualStyleBackColor = true;
            this.btnReadAllGLogData.Click += new System.EventHandler(this.btnReadAllGLogData_Click);
            // 
            // btnReadGLogData
            // 
            this.btnReadGLogData.Location = new System.Drawing.Point(15, 434);
            this.btnReadGLogData.Name = "btnReadGLogData";
            this.btnReadGLogData.Size = new System.Drawing.Size(65, 25);
            this.btnReadGLogData.TabIndex = 4;
            this.btnReadGLogData.Text = "Read";
            this.btnReadGLogData.UseVisualStyleBackColor = true;
            this.btnReadGLogData.Click += new System.EventHandler(this.btnReadGLogData_Click);
            // 
            // btnReadGLogDataLongID
            // 
            this.btnReadGLogDataLongID.Location = new System.Drawing.Point(538, 440);
            this.btnReadGLogDataLongID.Name = "btnReadGLogDataLongID";
            this.btnReadGLogDataLongID.Size = new System.Drawing.Size(139, 23);
            this.btnReadGLogDataLongID.TabIndex = 6;
            this.btnReadGLogDataLongID.Text = "ReadGLogDataLongID";
            this.btnReadGLogDataLongID.UseVisualStyleBackColor = true;
            this.btnReadGLogDataLongID.Click += new System.EventHandler(this.btnReadGLogDataLongID_Click);
            // 
            // checkBoxNew
            // 
            this.checkBoxNew.AutoSize = true;
            this.checkBoxNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBoxNew.Location = new System.Drawing.Point(684, 444);
            this.checkBoxNew.Name = "checkBoxNew";
            this.checkBoxNew.Size = new System.Drawing.Size(45, 16);
            this.checkBoxNew.TabIndex = 7;
            this.checkBoxNew.Text = "NEW?";
            this.checkBoxNew.UseVisualStyleBackColor = true;
            // 
            // LogManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(842, 479);
            this.Controls.Add(this.checkBoxNew);
            this.Controls.Add(this.btnReadGLogDataLongID);
            this.Controls.Add(this.btnEmptyGLogData);
            this.Controls.Add(this.btnReadAllGLogData);
            this.Controls.Add(this.btnReadGLogData);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.labelInfo);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "LogManagement";
            this.Text = "LogManagement";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LogManagement_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelInfo;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btnEmptyGLogData;
        private System.Windows.Forms.Button btnReadAllGLogData;
        private System.Windows.Forms.Button btnReadGLogData;
        private System.Windows.Forms.Button btnReadGLogDataLongID;
        private System.Windows.Forms.CheckBox checkBoxNew;
    }
}