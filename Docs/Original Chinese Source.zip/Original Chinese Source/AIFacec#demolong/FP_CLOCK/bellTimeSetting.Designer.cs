﻿namespace FPClient
{
    partial class bellTimeSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelInfo = new System.Windows.Forms.Label();
            this.btnReadSetting = new System.Windows.Forms.Button();
            this.btnWriteSetting = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textHour1 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textMinute1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textHour2 = new System.Windows.Forms.TextBox();
            this.textMinute2 = new System.Windows.Forms.TextBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textHour3 = new System.Windows.Forms.TextBox();
            this.textMinute3 = new System.Windows.Forms.TextBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textHour4 = new System.Windows.Forms.TextBox();
            this.textMinute4 = new System.Windows.Forms.TextBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textHour6 = new System.Windows.Forms.TextBox();
            this.textMinute6 = new System.Windows.Forms.TextBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textHour5 = new System.Windows.Forms.TextBox();
            this.textMinute5 = new System.Windows.Forms.TextBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textHour7 = new System.Windows.Forms.TextBox();
            this.textMinute7 = new System.Windows.Forms.TextBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textHour8 = new System.Windows.Forms.TextBox();
            this.textMinute8 = new System.Windows.Forms.TextBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBellCount = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelInfo
            // 
            this.labelInfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelInfo.Location = new System.Drawing.Point(23, 7);
            this.labelInfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(488, 25);
            this.labelInfo.TabIndex = 0;
            this.labelInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReadSetting
            // 
            this.btnReadSetting.Location = new System.Drawing.Point(56, 366);
            this.btnReadSetting.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnReadSetting.Name = "btnReadSetting";
            this.btnReadSetting.Size = new System.Drawing.Size(96, 29);
            this.btnReadSetting.TabIndex = 1;
            this.btnReadSetting.Text = "ReadSetting";
            this.btnReadSetting.UseVisualStyleBackColor = true;
            this.btnReadSetting.Click += new System.EventHandler(this.btnReadSetting_Click);
            // 
            // btnWriteSetting
            // 
            this.btnWriteSetting.Location = new System.Drawing.Point(190, 366);
            this.btnWriteSetting.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnWriteSetting.Name = "btnWriteSetting";
            this.btnWriteSetting.Size = new System.Drawing.Size(110, 29);
            this.btnWriteSetting.TabIndex = 1;
            this.btnWriteSetting.Text = "WriteSetting";
            this.btnWriteSetting.UseVisualStyleBackColor = true;
            this.btnWriteSetting.Click += new System.EventHandler(this.btnWriteSetting_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(352, 366);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(70, 29);
            this.button3.TabIndex = 1;
            this.button3.Text = "OK";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 72);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Point1:";
            // 
            // textHour1
            // 
            this.textHour1.Location = new System.Drawing.Point(180, 70);
            this.textHour1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textHour1.Name = "textHour1";
            this.textHour1.Size = new System.Drawing.Size(46, 21);
            this.textHour1.TabIndex = 3;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(117, 72);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textMinute1
            // 
            this.textMinute1.Location = new System.Drawing.Point(242, 70);
            this.textMinute1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textMinute1.Name = "textMinute1";
            this.textMinute1.Size = new System.Drawing.Size(46, 21);
            this.textMinute1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(228, 75);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = ":";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 47);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "Bell Point";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(188, 47);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "StartTime";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(115, 47);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "UseFlag";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 97);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 12);
            this.label7.TabIndex = 2;
            this.label7.Text = "Point2:";
            // 
            // textHour2
            // 
            this.textHour2.Location = new System.Drawing.Point(180, 94);
            this.textHour2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textHour2.Name = "textHour2";
            this.textHour2.Size = new System.Drawing.Size(46, 21);
            this.textHour2.TabIndex = 3;
            // 
            // textMinute2
            // 
            this.textMinute2.Location = new System.Drawing.Point(242, 94);
            this.textMinute2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textMinute2.Name = "textMinute2";
            this.textMinute2.Size = new System.Drawing.Size(46, 21);
            this.textMinute2.TabIndex = 3;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(117, 97);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 4;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(228, 100);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(11, 12);
            this.label8.TabIndex = 5;
            this.label8.Text = ":";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(34, 122);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 12);
            this.label9.TabIndex = 2;
            this.label9.Text = "Point3:";
            // 
            // textHour3
            // 
            this.textHour3.Location = new System.Drawing.Point(180, 119);
            this.textHour3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textHour3.Name = "textHour3";
            this.textHour3.Size = new System.Drawing.Size(46, 21);
            this.textHour3.TabIndex = 3;
            // 
            // textMinute3
            // 
            this.textMinute3.Location = new System.Drawing.Point(242, 119);
            this.textMinute3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textMinute3.Name = "textMinute3";
            this.textMinute3.Size = new System.Drawing.Size(46, 21);
            this.textMinute3.TabIndex = 3;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(117, 122);
            this.checkBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 4;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(228, 125);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 12);
            this.label10.TabIndex = 5;
            this.label10.Text = ":";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(34, 146);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 12);
            this.label11.TabIndex = 2;
            this.label11.Text = "Point4:";
            // 
            // textHour4
            // 
            this.textHour4.Location = new System.Drawing.Point(180, 144);
            this.textHour4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textHour4.Name = "textHour4";
            this.textHour4.Size = new System.Drawing.Size(46, 21);
            this.textHour4.TabIndex = 3;
            // 
            // textMinute4
            // 
            this.textMinute4.Location = new System.Drawing.Point(242, 144);
            this.textMinute4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textMinute4.Name = "textMinute4";
            this.textMinute4.Size = new System.Drawing.Size(46, 21);
            this.textMinute4.TabIndex = 3;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(117, 146);
            this.checkBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 4;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(228, 150);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(11, 12);
            this.label12.TabIndex = 5;
            this.label12.Text = ":";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(34, 196);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 12);
            this.label13.TabIndex = 2;
            this.label13.Text = "Point6:";
            // 
            // textHour6
            // 
            this.textHour6.Location = new System.Drawing.Point(180, 194);
            this.textHour6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textHour6.Name = "textHour6";
            this.textHour6.Size = new System.Drawing.Size(46, 21);
            this.textHour6.TabIndex = 3;
            // 
            // textMinute6
            // 
            this.textMinute6.Location = new System.Drawing.Point(242, 194);
            this.textMinute6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textMinute6.Name = "textMinute6";
            this.textMinute6.Size = new System.Drawing.Size(46, 21);
            this.textMinute6.TabIndex = 3;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(117, 196);
            this.checkBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(228, 199);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(11, 12);
            this.label14.TabIndex = 5;
            this.label14.Text = ":";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(34, 171);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 2;
            this.label15.Text = "Point5:";
            // 
            // textHour5
            // 
            this.textHour5.Location = new System.Drawing.Point(180, 169);
            this.textHour5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textHour5.Name = "textHour5";
            this.textHour5.Size = new System.Drawing.Size(46, 21);
            this.textHour5.TabIndex = 3;
            // 
            // textMinute5
            // 
            this.textMinute5.Location = new System.Drawing.Point(242, 169);
            this.textMinute5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textMinute5.Name = "textMinute5";
            this.textMinute5.Size = new System.Drawing.Size(46, 21);
            this.textMinute5.TabIndex = 3;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(117, 171);
            this.checkBox6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(15, 14);
            this.checkBox6.TabIndex = 4;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(228, 174);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(11, 12);
            this.label16.TabIndex = 5;
            this.label16.Text = ":";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(34, 221);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 12);
            this.label17.TabIndex = 2;
            this.label17.Text = "Point7:";
            // 
            // textHour7
            // 
            this.textHour7.Location = new System.Drawing.Point(180, 218);
            this.textHour7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textHour7.Name = "textHour7";
            this.textHour7.Size = new System.Drawing.Size(46, 21);
            this.textHour7.TabIndex = 3;
            // 
            // textMinute7
            // 
            this.textMinute7.Location = new System.Drawing.Point(242, 218);
            this.textMinute7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textMinute7.Name = "textMinute7";
            this.textMinute7.Size = new System.Drawing.Size(46, 21);
            this.textMinute7.TabIndex = 3;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(117, 221);
            this.checkBox7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(15, 14);
            this.checkBox7.TabIndex = 4;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(228, 224);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(11, 12);
            this.label18.TabIndex = 5;
            this.label18.Text = ":";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(34, 246);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 12);
            this.label19.TabIndex = 2;
            this.label19.Text = "Point8:";
            // 
            // textHour8
            // 
            this.textHour8.Location = new System.Drawing.Point(180, 243);
            this.textHour8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textHour8.Name = "textHour8";
            this.textHour8.Size = new System.Drawing.Size(46, 21);
            this.textHour8.TabIndex = 3;
            // 
            // textMinute8
            // 
            this.textMinute8.Location = new System.Drawing.Point(242, 243);
            this.textMinute8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textMinute8.Name = "textMinute8";
            this.textMinute8.Size = new System.Drawing.Size(46, 21);
            this.textMinute8.TabIndex = 3;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(117, 246);
            this.checkBox8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(15, 14);
            this.checkBox8.TabIndex = 4;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(228, 249);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(11, 12);
            this.label20.TabIndex = 5;
            this.label20.Text = ":";
            // 
            // textBellCount
            // 
            this.textBellCount.Location = new System.Drawing.Point(410, 243);
            this.textBellCount.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBellCount.Name = "textBellCount";
            this.textBellCount.Size = new System.Drawing.Size(46, 21);
            this.textBellCount.TabIndex = 3;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(334, 249);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 12);
            this.label21.TabIndex = 2;
            this.label21.Text = "Bell Count:";
            // 
            // bellTimeSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 404);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox8);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.textMinute5);
            this.Controls.Add(this.textHour5);
            this.Controls.Add(this.textBellCount);
            this.Controls.Add(this.textMinute8);
            this.Controls.Add(this.textHour8);
            this.Controls.Add(this.textMinute7);
            this.Controls.Add(this.textHour7);
            this.Controls.Add(this.textMinute6);
            this.Controls.Add(this.textHour6);
            this.Controls.Add(this.textMinute4);
            this.Controls.Add(this.textHour4);
            this.Controls.Add(this.textMinute3);
            this.Controls.Add(this.textHour3);
            this.Controls.Add(this.textMinute2);
            this.Controls.Add(this.textHour2);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.textMinute1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textHour1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnWriteSetting);
            this.Controls.Add(this.btnReadSetting);
            this.Controls.Add(this.labelInfo);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "bellTimeSetting";
            this.Text = "bellTimeSetting";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.bellTimeSetting_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelInfo;
        private System.Windows.Forms.Button btnReadSetting;
        private System.Windows.Forms.Button btnWriteSetting;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textHour1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textMinute1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textHour2;
        private System.Windows.Forms.TextBox textMinute2;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textHour3;
        private System.Windows.Forms.TextBox textMinute3;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textHour4;
        private System.Windows.Forms.TextBox textMinute4;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textHour6;
        private System.Windows.Forms.TextBox textMinute6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textHour5;
        private System.Windows.Forms.TextBox textMinute5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textHour7;
        private System.Windows.Forms.TextBox textMinute7;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textHour8;
        private System.Windows.Forms.TextBox textMinute8;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBellCount;
        private System.Windows.Forms.Label label21;
    }
}